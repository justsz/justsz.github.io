# Travelling Salesman Code

To run:

```
$ python tsp.py  7 scottish_cities.pickled tmp.dat scottish_city_loc.csv
```
